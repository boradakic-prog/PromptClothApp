package com.bora.promptcloth

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.bora.promptcloth.PromptBuilder.*
import com.bora.promptcloth.ui.theme.AppTheme
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { App() } }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun App() {
    val context = LocalContext.current

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var gender by remember { mutableStateOf(Gender.UNISEX) }
    var pose by remember { mutableStateOf(Pose.MANNEQUIN) }
    var background by remember { mutableStateOf(Background.STUDIO) }
    var aspect by remember { mutableStateOf(Aspect.AR_9_16) }

    var hoodOnHead by remember { mutableStateOf(false) }
    var leftZipperVisible by remember { mutableStateOf(false) }
    var cuffsTurnedUp by remember { mutableStateOf(false) }
    var furTrimFramingFace by remember { mutableStateOf(false) }
    var beltFastened by remember { mutableStateOf(false) }
    var lockPixelsStrict by remember { mutableStateOf(true) }
    var material by remember { mutableStateOf(GarmentMaterial.AUTO) }

    var prompt by remember { mutableStateOf("") }

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> imageUri = uri }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Prompt Cloth") })
    }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Pregled učitane slike", fontWeight = FontWeight.Bold)
                    if (imageUri != null) {
                        Image(
                            painter = rememberAsyncImagePainter(imageUri),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(240.dp)
                                .clip(RoundedCornerShape(16.dp))
                        )
                    } else {
                        Text("Niste učitali sliku.")
                    }
                    Button(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Text("Učitaj sliku odevnog predmeta")
                    }
                }
            }

            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Podešavanja", fontWeight = FontWeight.Bold)
                    Text("Pol / target")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(label = { Text("Muški") }, selected = gender == Gender.MALE, onClick = { gender = Gender.MALE })
                        FilterChip(label = { Text("Ženski") }, selected = gender == Gender.FEMALE, onClick = { gender = Gender.FEMALE })
                        FilterChip(label = { Text("Unisex") }, selected = gender == Gender.UNISEX, onClick = { gender = Gender.UNISEX })
                    }
                    Text("Poza")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(label = { Text("Manekenska") }, selected = pose == Pose.MANNEQUIN, onClick = { pose = Pose.MANNEQUIN })
                        FilterChip(label = { Text("High-fashion") }, selected = pose == Pose.FASHION, onClick = { pose = Pose.FASHION })
                    }
                    Text("Pozadina")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(label = { Text("Studio") }, selected = background == Background.STUDIO, onClick = { background = Background.STUDIO })
                        FilterChip(label = { Text("Svetli gradijent") }, selected = background == Background.GRADIENT, onClick = { background = Background.GRADIENT })
                    }
                    Text("Odnos stranica")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(label = { Text("9:16") }, selected = aspect == Aspect.AR_9_16, onClick = { aspect = Aspect.AR_9_16 })
                        FilterChip(label = { Text("4:5") }, selected = aspect == Aspect.AR_4_5, onClick = { aspect = Aspect.AR_4_5 })
                        FilterChip(label = { Text("16:9") }, selected = aspect == Aspect.AR_16_9, onClick = { aspect = Aspect.AR_16_9 })
                    }
                }
            }

            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Brzi prekidači", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Kapuljača na glavi")
                        Switch(checked = hoodOnHead, onCheckedChange = { hoodOnHead = it })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Levi rajsferšlus vidljiv")
                        Switch(checked = leftZipperVisible, onCheckedChange = { leftZipperVisible = it })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Krzno oko lica")
                        Switch(checked = furTrimFramingFace, onCheckedChange = { furTrimFramingFace = it })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Podvrnute manžetne")
                        Switch(checked = cuffsTurnedUp, onCheckedChange = { cuffsTurnedUp = it })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Kaiš zakopčan")
                        Switch(checked = beltFastened, onCheckedChange = { beltFastened = it })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Zaključaj piksele (0% odstupanja)")
                        Switch(checked = lockPixelsStrict, onCheckedChange = { lockPixelsStrict = it })
                    }
                    Text("Materijal")
                    FlowRow(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { material = GarmentMaterial.AUTO }, label = { Text("Auto") })
                        AssistChip(onClick = { material = GarmentMaterial.MATTE_LEATHER_MONTON }, label = { Text("Mat koža / monton") })
                        AssistChip(onClick = { material = GarmentMaterial.SUEDE }, label = { Text("Suede") })
                        AssistChip(onClick = { material = GarmentMaterial.GLOSSY_LEATHER }, label = { Text("Sjajna koža") })
                        AssistChip(onClick = { material = GarmentMaterial.KNIT }, label = { Text("Knit") })
                        AssistChip(onClick = { material = GarmentMaterial.COTTON }, label = { Text("Pamuk") })
                        AssistChip(onClick = { material = GarmentMaterial.WOOL }, label = { Text("Vuna") })
                    }
                }
            }

            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                val opts = Options(
                    gender = gender,
                    pose = pose,
                    background = background,
                    aspect = aspect,
                    hoodOnHead = hoodOnHead,
                    leftZipperVisible = leftZipperVisible,
                    cuffsTurnedUp = cuffsTurnedUp,
                    furTrimFramingFace = furTrimFramingFace,
                    beltFastened = beltFastened,
                    lockPixelsStrict = lockPixelsStrict,
                    material = material
                )
                prompt = PromptBuilder.build(imageUri, opts)
            }) { Text("Generiši prompt") }

            if (prompt.isNotBlank()) {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Generisani prompt", fontWeight = FontWeight.Bold)
                        Text(prompt)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            Button(onClick = { cm.setPrimaryClip(ClipData.newPlainText("prompt", prompt)) }) { Text("Kopiraj") }
                            Button(onClick = {
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, prompt)
                                }
                                context.startActivity(Intent.createChooser(share, "Podeli"))
                            }) { Text("Podeli") }
                        }
                    }
                }
            }
        }
    }
}
