package com.bora.promptcloth

import android.net.Uri

object PromptBuilder {
    data class Options(
        val gender: Gender,
        val pose: Pose,
        val background: Background,
        val aspect: Aspect,
        val resolutionLabel: String = "16K HD",
        val hoodOnHead: Boolean = false,
        val leftZipperVisible: Boolean = false,
        val cuffsTurnedUp: Boolean = false,
        val furTrimFramingFace: Boolean = false,
        val beltFastened: Boolean = false,
        val lockPixelsStrict: Boolean = true,
        val material: GarmentMaterial = GarmentMaterial.AUTO
    )
    enum class Gender { MALE, FEMALE, UNISEX }
    enum class Pose { MANNEQUIN, FASHION }
    enum class Background { STUDIO, GRADIENT }
    enum class Aspect { AR_9_16, AR_4_5, AR_16_9 }
    enum class GarmentMaterial { AUTO, MATTE_LEATHER_MONTON, SUEDE, GLOSSY_LEATHER, KNIT, COTTON, WOOL }

    fun build(referenceUri: Uri?, opts: Options): String {
        val genderText = when (opts.gender) {
            Gender.MALE -> "male model"
            Gender.FEMALE -> "female model"
            Gender.UNISEX -> "professional fashion model"
        }
        val poseText = when (opts.pose) {
            Pose.MANNEQUIN -> "high-fashion mannequin pose, neutral expression, full body visible"
            Pose.FASHION -> "confident high-fashion pose, full body, neutral expression"
        }
        val bgText = when (opts.background) {
            Background.STUDIO -> "clean studio background with soft professional lighting"
            Background.GRADIENT -> "minimal light-toned gradient studio background with soft cinematic shadows"
        }
        val arText = when (opts.aspect) {
            Aspect.AR_9_16 -> "9:16 vertical format"
            Aspect.AR_4_5 -> "4:5 portrait format"
            Aspect.AR_16_9 -> "16:9 horizontal format"
        }
        val refBlock = referenceUri?.let { "\nReference image: " + it.toString() } ?: ""

        val materialHint = when (opts.material) {
            GarmentMaterial.AUTO -> ""
            GarmentMaterial.MATTE_LEATHER_MONTON -> "Material: matte leather monton with suede-like matte texture and visible fur lining/trim."
            GarmentMaterial.SUEDE -> "Material: suede (matte, fine nap)."
            GarmentMaterial.GLOSSY_LEATHER -> "Material: glossy leather (polished sheen)."
            GarmentMaterial.KNIT -> "Material: knit fabric (visible knit texture)."
            GarmentMaterial.COTTON -> "Material: woven cotton (matte, soft)."
            GarmentMaterial.WOOL -> "Material: wool (natural fibers, subtle fuzz)."
        }

        val switches = mutableListOf<String>()
        if (opts.hoodOnHead) switches.add("Hood must be worn on the head.")
        if (opts.leftZipperVisible) switches.add("Ensure the LEFT-side zipper is visible exactly as in the reference.")
        if (opts.cuffsTurnedUp) switches.add("Keep sleeves with turned-up fur cuffs exactly as shown.")
        if (opts.furTrimFramingFace) switches.add("Black fur trim must naturally frame the face.")
        if (opts.beltFastened) switches.add("Belt must be present and fastened as in the reference.")
        if (opts.lockPixelsStrict) switches.add("No redesign, no reinterpretation — lock all garment pixels to match the reference 1:1.")
        val switchesText = switches.joinToString(" ")

        return ("""
    Ultra-realistic ${opts.resolutionLabel} full-body ${genderText}, ${arText}. ${poseText}. ${bgText}.

    The model must wear the EXACT SAME clothing item from the reference image — 100% identical with zero deviation.
    Match every detail: color, fabric, texture, stitching, shine, cut, proportions, silhouette, hardware (zippers, buttons, belts, seams, pockets, labels), prints/patterns, fur/lining, and trims. No redesign or interpretation.
    ${materialHint}
    ${switchesText}

    Preserve true-to-life scale and drape. Keep natural fabric folds and realistic material response to light.

    Rendering requirements: ultra-sharp, crystal-clear details on garment and face; noise-free; realistic skin texture; natural shadows; no AI blur; no smoothing; no distortion.

    DO NOT change or alter anything on the clothing item. Absolutely no changes to color, texture, shape, or details. Zero stylization. Output must look like it was originally photographed on the model.
    ${refBlock}
        """).trim()
    }
}
