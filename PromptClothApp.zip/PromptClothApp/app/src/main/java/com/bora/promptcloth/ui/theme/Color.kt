package com.bora.promptcloth.ui.theme

import androidx.compose.ui.graphics.Color

val AppPrimary = Color(0xFF1F6FEB)
val AppBackground = Color(0xFFF6F8FB)
